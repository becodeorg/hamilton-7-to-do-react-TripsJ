
const Submitbutton = function () {return <input type="submit">Submit</input>};
export default Submitbutton