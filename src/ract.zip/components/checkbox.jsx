const Checkbox = function () {return <input type="checkbox"> </input> };
export default Checkbox