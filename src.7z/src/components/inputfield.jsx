const Inputfield = function () {return <input type="text"></input>};
export default Inputfield

